/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Equipamento;


/**
 *
 * @author Admin
 */
public class EquipamentoDAO {
    Connection conexao = Conexao.getConexao();
    
     public void CadastrarEquipamento(Equipamento equipamento) throws SQLException {
       // Connection conexao = Conexao.getConexao();

        String sql = "INSERT INTO tbl_equipamentos(nome,descricao,quantidade,marca,sala,estadoConservacao,patrimonio)VALUES(?,?,?,?,?,?,?)";

        PreparedStatement ps = conexao.prepareStatement(sql);

        ps.setString(1, equipamento.getNome());
        ps.setString(2, equipamento.getDescricao());
        ps.setInt(3, equipamento.getQuantidade());
        ps.setString(4, equipamento.getMarca());
        ps.setInt(5, equipamento.getSala());
        ps.setString(6, equipamento.getEstadoConservacao());
        ps.setString(7,equipamento.getPatrimonio());
    
        ps.execute();
    }
     
     public void pesquisar(Equipamento equipamento) throws SQLException {
        Connection con = null;
        //Connection conexao = Conexao.getConexao();
        String sql = "SELECT * FROM tbl_equipamentos where patrimonio=?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        
        ps.setString(1, equipamento.getPatrimonio());
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            equipamento.setNome(rs.getString(2));
            equipamento.setDescricao(rs.getString(3));
            equipamento.setMarca(rs.getString(4));
        }
    
     }
}
